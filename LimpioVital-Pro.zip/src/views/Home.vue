<template>
  <div class="container">
    <h1>Bienvenido a LimpioVital Pro</h1>
    <p>Proyecto universitario avanzado con diseño profesional.</p>
    <button class="btn-primary">Comenzar</button>
  </div>
</template>

<style scoped>
.container {
  padding: 3rem;
  text-align: center;
}
</style>
