<template>
  <nav class="navbar">
    <div class="logo">LimpioVital Pro</div>
    <div>
      <router-link to="/">Inicio</router-link>
      <router-link to="/dashboard">Dashboard</router-link>
    </div>
  </nav>
</template>

<style scoped>
.navbar {
  display: flex;
  justify-content: space-between;
  padding: 1rem 2rem;
  background: white;
  box-shadow: 0 4px 10px rgba(0,0,0,0.05);
}
.logo {
  font-weight: 700;
  color: var(--primary);
}
a {
  margin-left: 20px;
  text-decoration: none;
  color: var(--text-dark);
}
</style>
